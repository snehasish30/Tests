using HotelBooking.Business;
using HotelBooking.Configurations;
using HotelBooking.Controllers;
using HotelBooking.Integrations;
using HotelBooking.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using System.IO;
using Xunit.Sdk;

namespace HotelBooking.Tests
{
    public class HotelBookingControllerTests
    {
        private readonly HotelBookingBusiness _mockHotelBookingBusiness;
        private readonly HotelBookingController _mockHotelBookingController;

        public HotelBookingControllerTests()
        {
            _mockHotelBookingBusiness = new HotelBookingBusiness();
            _mockHotelBookingController = new HotelBookingController(new Mock<ILogger<HotelBookingController>>().Object, new Mock<IConfigurationManager>().Object, new Mock<IHotelBookingBusiness>().Object);
        }

        [Fact]
        public void GetHotelModels_ReturnsListHotels()
        {
            var sampleHotelBookingModel = GenerateMockHoTelBooking("\\TestJson\\SampletestJson.json");
            var hotelId = "7294";
            DateTime arrivalDate = System.DateTime.Now;
            var output = _mockHotelBookingBusiness.GetHotelBookingModels(sampleHotelBookingModel, hotelId, arrivalDate);
            Assert.IsType<List<HotelBookingModel>>(output);
        }
        [Fact]
        public void GetNoHotels_ReturnsNoError()
        {
            var sampleHotelBookingModel = GenerateMockHoTelBooking("\\TestJson\\SampletestJson.json");
            var hotelId = "167";
            DateTime arrivalDate = System.DateTime.Now;
            var output = _mockHotelBookingBusiness.GetHotelBookingModels(sampleHotelBookingModel, hotelId, arrivalDate);
            Assert.NotNull(output);
        }
        [Fact]
        public void CheckInputParameters_ReturnsException()
        {
            var hotelId = "167";
            string arrivalDate = "";
            Assert.Throws<System.FormatException>(()=>_mockHotelBookingController.Get(hotelId, Convert.ToDateTime(arrivalDate)));
        }
        [Fact]
        public void NoFileInTheDirectory_ReturnsException()
        {
            var baseDirectory = Directory.GetCurrentDirectory();
            var path = "";
            Assert.Throws<System.ArgumentException>(()=>ReadAndParseJsonFileWithNewtonsoftJson.UseUserDefinedObjectWithNewtonsoftJson(path));
        }

        private List<HotelBookingModel> GenerateMockHoTelBooking(string path)
    {
        var baseDirectory = Directory.GetCurrentDirectory();
        using StreamReader reader = new(baseDirectory + path);
        var json = reader.ReadToEnd();
        List<HotelBookingModel> hotelbookingModel = JsonConvert.DeserializeObject<List<HotelBookingModel>>(json);
        return hotelbookingModel;
    }
}
}