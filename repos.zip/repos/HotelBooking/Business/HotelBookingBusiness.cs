﻿using HotelBooking.Models;

namespace HotelBooking.Business
{
    public class HotelBookingBusiness : IHotelBookingBusiness
    {
        public List<HotelBookingModel> GetHotelBookingModels(List<HotelBookingModel> listHotelbookignModels, string hotelId, DateTime arrivalDate)
        {
            var listOutputHotelModels = new List<HotelBookingModel>();
          
            var hotelRates = new List<HotelRate>();
            foreach (var hotelModel in listHotelbookignModels)
            {
                var outputHotelModels = new HotelBookingModel();
                var hotel = hotelModel.hotel;
                var targetRates = hotelModel.hotelRates;
                if (hotel?.hotelID.ToString() == hotelId)
                {
                    outputHotelModels.hotel = hotel;
                    foreach (var targetRate in targetRates.Where(x => DateTime.Compare(x.targetDay.Date, arrivalDate)==0))
                    {
                        hotelRates.Add(targetRate);
                    }
                    outputHotelModels.hotelRates = hotelRates;
                    listOutputHotelModels.Add(outputHotelModels);
                }
             
            }
            return listOutputHotelModels;
        }
    }
}
