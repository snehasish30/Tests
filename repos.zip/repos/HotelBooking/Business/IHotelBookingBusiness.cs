﻿using HotelBooking.Models;

namespace HotelBooking.Business
{
    public interface IHotelBookingBusiness
    {
        public List<HotelBookingModel> GetHotelBookingModels(List<HotelBookingModel> listHotelbookignModels,string hotelId, DateTime arrivalDate); 
    }
}
