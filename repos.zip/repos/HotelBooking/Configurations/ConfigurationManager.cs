﻿namespace HotelBooking.Configurations
{
    public class ConfigurationManager : IConfigurationManager
    {
        private readonly IConfiguration _configuration;
        public ConfigurationManager(IConfiguration configuration)
        {
            this._configuration = configuration;
        }

        public string FilePath
        {
            get
            {
                return this._configuration["AppSeettings:FilePath"];
            }
            
        }

        public IConfigurationSection GetConfigurationSection(string key)
        {
            return this._configuration.GetSection(key);
        }
    }
}
