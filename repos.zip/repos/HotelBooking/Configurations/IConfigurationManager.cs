﻿namespace HotelBooking.Configurations
{
    public interface IConfigurationManager
    {
        public string FilePath { get;  }

        IConfigurationSection GetConfigurationSection(string Key);

    }
}
