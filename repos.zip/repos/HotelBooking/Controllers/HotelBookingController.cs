using HotelBooking.Business;
using HotelBooking.Configurations;
using HotelBooking.ErrorHandler;
using HotelBooking.Integrations;
using HotelBooking.Models;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace HotelBooking.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HotelBookingController : ControllerBase
    {
        private readonly ILogger<HotelBookingController> _logger;
        private IConfigurationManager _configurationManager;
        private IHotelBookingBusiness _hotelBookingBusiness;

        public HotelBookingController(ILogger<HotelBookingController> logger, IConfigurationManager configurationManager, IHotelBookingBusiness hotelBookingBusiness)
        {
            _logger = logger;
            _configurationManager = configurationManager;
            _hotelBookingBusiness = hotelBookingBusiness; 
        }

        [HttpGet(Name = "GetHotelDetails")]
        public IActionResult Get(string HotelID, DateTime ArrivalDate)
        {
                var path = _configurationManager.GetConfigurationSection("FilePathKeys").GetSection("FilePath").Value;
                var hotelBookingModel = ReadAndParseJsonFileWithNewtonsoftJson.UseUserDefinedObjectWithNewtonsoftJson(FileService.CreatePath(path));
                var outputList = _hotelBookingBusiness.GetHotelBookingModels(hotelBookingModel, HotelID, ArrivalDate);
                return new JsonResult(outputList);
        }       
        }
  }
