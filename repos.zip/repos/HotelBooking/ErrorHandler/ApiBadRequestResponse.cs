﻿namespace HotelBooking.ErrorHandler
{
    public class ApiBadRequestResponse : ApiResponse
    {
        public object Result { get; }

        public ApiBadRequestResponse(object result)
            : base(400)
        {
            Result = result;
        }
    }
}
