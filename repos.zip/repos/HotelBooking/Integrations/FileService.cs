﻿namespace HotelBooking.Integrations
{
    public static class FileService
    {
        static string baseDirectory = "";
        static FileService()
        {
            baseDirectory = Directory.GetCurrentDirectory();
        }
        public static string CreatePath(string path)
        {
            return baseDirectory + path;
        }
    }
}
