﻿using HotelBooking.Models;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HotelBooking.Integrations
{
    public static class ReadAndParseJsonFileWithNewtonsoftJson
    {
        public static List<HotelBookingModel> UseUserDefinedObjectWithNewtonsoftJson(string _sampleJsonFilePath)
        {
            using StreamReader reader = new(_sampleJsonFilePath);
            var json = reader.ReadToEnd();
            List<HotelBookingModel> hotelbookingModel = JsonConvert.DeserializeObject<List<HotelBookingModel>>(json);
            return hotelbookingModel;
        }
    }
}
