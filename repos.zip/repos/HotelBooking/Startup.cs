﻿using HotelBooking.Business;
using HotelBooking.Configurations;
using Microsoft.Extensions.Configuration;

namespace HotelBooking
{
    public class Startup
    {
        public Startup(IConfigurationRoot configuration)
        {
            Configuration = configuration;
        }
        public IConfigurationRoot Configuration { get; }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSingleton<IConfigurationManager, Configurations.ConfigurationManager>();
            services.AddScoped<IHotelBookingBusiness, HotelBookingBusiness>();
            


        }
        public void Configure(IApplicationBuilder app)
        {
            app.UseRouting();
            app.UseEndpoints(x=>x.MapControllers());
        }
    }
}
